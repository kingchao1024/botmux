'use strict';

const assert = require('node:assert/strict');
const { EventEmitter, once } = require('node:events');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const net = require('node:net');
const { setTimeout: delay } = require('node:timers/promises');
const test = require('node:test');
const { spawn } = require('node:child_process');
const { WebSocketServer, WebSocket } = require('ws');
const { runServer } = require('../bridge.js');

const HERE = path.resolve(__dirname, '..');
const FAKE_DSH = path.join(HERE, 'test', 'fixtures', 'dsh');
const TIMEOUT_MS = 2_000;

function withTimeout(promise, label) {
    return Promise.race([
        promise,
        delay(TIMEOUT_MS).then(() => { throw new Error(`timed out: ${label}`); }),
    ]);
}

async function waitFor(condition, label) {
    const deadline = Date.now() + TIMEOUT_MS;
    while (!condition()) {
        if (Date.now() >= deadline) throw new Error(`timed out: ${label}`);
        await delay(10);
    }
}

function openSocket(url) {
    const socket = new WebSocket(url);
    return withTimeout(once(socket, 'open').then(() => socket), `open ${url}`);
}

function nextMessage(socket) {
    return withTimeout(once(socket, 'message').then(([data]) => JSON.parse(data.toString())), 'WebSocket message');
}

function nextClose(socket) {
    return withTimeout(once(socket, 'close').then(([code, reason]) => ({ code, reason: reason.toString() })), 'WebSocket close');
}

async function closeSocket(socket) {
    if (!socket || socket.readyState === WebSocket.CLOSED) return;
    const closed = once(socket, 'close');
    socket.terminate();
    await withTimeout(closed, 'socket cleanup');
}

async function startBridge({ token = '', authTimeoutMs, maxStdoutBufferBytes, extraEnv = {}, timers = {} } = {}) {
    const record = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-bridge-test-')), 'argv.json');
    const runtime = runServer(
        { spawn, WebSocketServer },
        {
            port: 0,
            token,
            authTimeoutMs,
            maxStdoutBufferBytes,
            ...timers,
            env: { ...process.env, PATH: `${path.dirname(FAKE_DSH)}:${process.env.PATH}`, FAKE_DSH_RECORD: record, ...extraEnv },
        },
    );
    await withTimeout(once(runtime.wss, 'listening'), 'bridge listen');
    const address = runtime.wss.address();
    return { ...runtime, record, cleanupDir: path.dirname(record), url: `ws://127.0.0.1:${address.port}` };
}

async function stopBridge(runtime, sockets = []) {
    await Promise.allSettled(sockets.map(closeSocket));
    await runtime.close();
    await waitFor(() => runtime.dsh.exitCode !== null || runtime.dsh.killed, 'fake dsh cleanup');
    if (runtime.cleanupDir) fs.rmSync(runtime.cleanupDir, { recursive: true, force: true });
}

async function startInjectedBridge(write) {
    const child = new EventEmitter();
    child.stdout = new EventEmitter();
    child.stdout.setEncoding = () => {};
    child.stderr = new EventEmitter();
    child.stderr.setEncoding = () => {};
    child.stdin = { write };
    child.kill = () => { child.killed = true; child.exitCode = 0; child.emit('exit', 0); };
    const runtime = runServer({ spawn: () => child, WebSocketServer }, { port: 0 });
    await withTimeout(once(runtime.wss, 'listening'), 'injected bridge listen');
    return { ...runtime, url: `ws://127.0.0.1:${runtime.wss.address().port}` };
}

async function startInjectedRuntime({ write = () => true, stdin, options = {}, exit } = {}) {
    const child = new EventEmitter();
    child.stdout = new EventEmitter();
    child.stdout.setEncoding = () => {};
    child.stderr = new EventEmitter();
    child.stderr.setEncoding = () => {};
    child.stdin = stdin || { write };
    child.kill = () => { child.killed = true; child.exitCode = 0; child.emit('exit', 0); };
    const runtime = runServer({ spawn: () => child, WebSocketServer, exit }, { port: 0, ...options });
    await withTimeout(once(runtime.wss, 'listening'), 'injected bridge listen');
    return { ...runtime, url: `ws://127.0.0.1:${runtime.wss.address().port}` };
}

test('spawns fake dsh through PATH exactly as dsh --profile acp', async () => {
    const runtime = await startBridge();
    try {
        await waitFor(() => fs.existsSync(runtime.record), 'fake dsh argv record');
        assert.deepEqual(JSON.parse(fs.readFileSync(runtime.record, 'utf8')), ['--profile', 'acp']);
    } finally {
        await stopBridge(runtime);
    }
});

test('refuses a non-loopback listener before spawning dsh', () => {
    assert.throws(
        () => runServer({ spawn, WebSocketServer }, { host: '0.0.0.0' }),
        /must bind to 127\.0\.0\.1/,
    );
});

test('terminates an already-spawned child when WebSocket server construction throws', () => {
    const child = new EventEmitter();
    child.stdout = new EventEmitter();
    child.stdout.setEncoding = () => {};
    child.stderr = new EventEmitter();
    child.stderr.setEncoding = () => {};
    child.stdin = { write: () => true };
    child.kill = () => { child.killed = true; };
    class ThrowingWebSocketServer {
        constructor() { throw new Error('listen setup failed'); }
    }
    assert.throws(() => runServer({ spawn: () => child, WebSocketServer: ThrowingWebSocketServer }), /listen setup failed/);
    assert.equal(child.killed, true);
});

test('terminates child and exits once when WebSocket listen emits an error', async () => {
    const blocker = net.createServer();
    await withTimeout(new Promise((resolve) => blocker.listen(0, '127.0.0.1', resolve)), 'occupy bridge port');
    const child = new EventEmitter();
    child.stdout = new EventEmitter();
    child.stdout.setEncoding = () => {};
    child.stderr = new EventEmitter();
    child.stderr.setEncoding = () => {};
    child.stdin = { write: () => true };
    child.kill = () => { child.killed = true; child.exitCode = 0; child.emit('exit', 0); };
    const exits = [];
    try {
        runServer(
            { spawn: () => child, WebSocketServer, exit: (code) => exits.push(code) },
            { port: blocker.address().port },
        );
        await waitFor(() => exits.length === 1, 'listen error shutdown');
        assert.equal(child.killed, true);
        assert.deepEqual(exits, [1]);
    } finally {
        await new Promise((resolve) => blocker.close(resolve));
    }
});

test('shuts down child and exits once for injected SIGTERM/SIGINT/SIGHUP', async () => {
    const signalProcess = new EventEmitter();
    const exits = [];
    const runtime = await startInjectedRuntime({ options: { signalProcess }, exit: (code) => exits.push(code) });
    try {
        const closed = withTimeout(once(runtime.wss, 'close'), 'signal closes server');
        signalProcess.emit('SIGTERM');
        await closed;
        signalProcess.emit('SIGINT');
        signalProcess.emit('SIGHUP');
        assert.equal(runtime.dsh.killed, true);
        assert.deepEqual(exits, [0]);
    } finally {
        await stopBridge(runtime);
    }
});

test('forwards DSH output without a Node global WebSocket', async () => {
    const originalWebSocket = globalThis.WebSocket;
    const runtime = await startBridge();
    let socket;
    try {
        delete globalThis.WebSocket;
        socket = await openSocket(runtime.url);
        socket.send(JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'initialize', params: {} }));
        assert.equal((await nextMessage(socket)).method, 'initialize');
    } finally {
        if (originalWebSocket === undefined) delete globalThis.WebSocket;
        else globalThis.WebSocket = originalWebSocket;
        await stopBridge(runtime, [socket]);
    }
});

test('relays initialize/new/prompt/update/permission/cancel as bidirectional NDJSON', async () => {
    const runtime = await startBridge();
    let socket;
    try {
        socket = await openSocket(runtime.url);
        const expected = [
            ['initialize', { protocolVersion: 1 }],
            ['session/new', { cwd: '/workspace' }],
            ['session/prompt', { sessionId: 's-1', prompt: 'hello' }],
            ['session/request_permission', { sessionId: 's-1', options: ['allow'] }],
            ['session/cancel', { sessionId: 's-1' }],
        ];
        for (const [method, params] of expected) {
            socket.send(JSON.stringify({ jsonrpc: '2.0', id: method, method, params }));
            const response = await nextMessage(socket);
            assert.equal(response.method, method === 'session/prompt' ? 'session/update' : method);
            assert.deepEqual(response.params, params);
        }
    } finally {
        await stopBridge(runtime, [socket]);
    }
});

test('reassembles partial NDJSON, ignores invalid JSON, and relays dsh stderr without poisoning frames', async () => {
    const runtime = await startBridge();
    let socket;
    try {
        socket = await openSocket(runtime.url);
        socket.send(JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'partial', params: { ok: true } }));
        assert.deepEqual(await nextMessage(socket), { jsonrpc: '2.0', method: 'partial', params: { ok: true } });

        socket.send(JSON.stringify({ jsonrpc: '2.0', id: 2, method: 'invalid-json', params: {} }));
        await delay(50);
        socket.send(JSON.stringify({ jsonrpc: '2.0', id: 3, method: 'stderr', params: { ok: true } }));
        assert.deepEqual(await nextMessage(socket), { jsonrpc: '2.0', method: 'stderr', params: { ok: true } });
    } finally {
        await stopBridge(runtime, [socket]);
    }
});

test('terminates child and server when an unterminated DSH stdout line exceeds its byte limit', async () => {
    const runtime = await startBridge({ maxStdoutBufferBytes: 8 });
    let socket;
    try {
        socket = await openSocket(runtime.url);
        const serverClosed = withTimeout(once(runtime.wss, 'close'), 'oversized stdout closes server');
        runtime.dsh.stdout.emit('data', '123456789');
        await serverClosed;
        await waitFor(() => runtime.dsh.exitCode !== null || runtime.dsh.killed, 'oversized stdout terminates child');
    } finally {
        await stopBridge(runtime, [socket]);
    }
});

test('terminates child and server when a complete DSH stdout line exceeds its byte limit', async () => {
    const runtime = await startBridge({ maxStdoutBufferBytes: 8 });
    let socket;
    try {
        socket = await openSocket(runtime.url);
        const serverClosed = withTimeout(once(runtime.wss, 'close'), 'oversized complete stdout line closes server');
        runtime.dsh.stdout.emit('data', '123456789\n');
        await serverClosed;
        await waitFor(() => runtime.dsh.exitCode !== null || runtime.dsh.killed, 'oversized complete stdout terminates child');
    } finally {
        await stopBridge(runtime, [socket]);
    }
});

test('allows a raw whitespace-only line exactly at the stdout byte limit', async () => {
    const runtime = await startBridge({ maxStdoutBufferBytes: 8 });
    try {
        runtime.dsh.stdout.emit('data', '        \n');
        await delay(20);
        assert.notEqual(runtime.wss._server, null);
        assert.equal(runtime.dsh.killed, false);
    } finally {
        await stopBridge(runtime);
    }
});

test('terminates child and server for a whitespace-only line one byte above the limit in one chunk', async () => {
    const runtime = await startBridge({ maxStdoutBufferBytes: 8 });
    try {
        const serverClosed = withTimeout(once(runtime.wss, 'close'), 'oversized whitespace line closes server');
        runtime.dsh.stdout.emit('data', '         \n');
        await serverClosed;
        await waitFor(() => runtime.dsh.exitCode !== null || runtime.dsh.killed, 'oversized whitespace line terminates child');
    } finally {
        await stopBridge(runtime);
    }
});

test('terminates child and server for a whitespace-only line one byte above the limit across chunks', async () => {
    const runtime = await startBridge({ maxStdoutBufferBytes: 8 });
    try {
        runtime.dsh.stdout.emit('data', '   ');
        const serverClosed = withTimeout(once(runtime.wss, 'close'), 'cross-chunk whitespace line closes server');
        runtime.dsh.stdout.emit('data', '      \n');
        await serverClosed;
        await waitFor(() => runtime.dsh.exitCode !== null || runtime.dsh.killed, 'cross-chunk whitespace line terminates child');
    } finally {
        await stopBridge(runtime);
    }
});

test('counts original complete-line bytes before trimming whitespace', async () => {
    const runtime = await startBridge({ maxStdoutBufferBytes: 64 });
    let socket;
    try {
        socket = await openSocket(runtime.url);
        const payload = JSON.stringify({ jsonrpc: '2.0', method: 'ok', params: {} });
        const line = ' '.repeat(64 - Buffer.byteLength(payload)) + payload;
        assert.equal(Buffer.byteLength(line), 64);
        const forwarded = nextMessage(socket);
        runtime.dsh.stdout.emit('data', line + '\n');
        assert.deepEqual(await forwarded, JSON.parse(payload));
    } finally {
        await stopBridge(runtime, [socket]);
    }
});

test('rejects a complete whitespace-padded NDJSON line one byte above its byte limit', async () => {
    const runtime = await startBridge({ maxStdoutBufferBytes: 64 });
    let socket;
    try {
        socket = await openSocket(runtime.url);
        const payload = JSON.stringify({ jsonrpc: '2.0', method: 'ok', params: {} });
        const line = ' '.repeat(65 - Buffer.byteLength(payload)) + payload;
        assert.equal(Buffer.byteLength(line), 65);
        const serverClosed = withTimeout(once(runtime.wss, 'close'), 'whitespace-padded complete line closes server');
        runtime.dsh.stdout.emit('data', line + '\n');
        await serverClosed;
        await waitFor(() => runtime.dsh.exitCode !== null || runtime.dsh.killed, 'whitespace-padded complete line terminates child');
    } finally {
        await stopBridge(runtime, [socket]);
    }
});

test('rejects invalid token, permits first-frame token, and replaces a prior client', async () => {
    const runtime = await startBridge({ token: 'pair-me' });
    let rejected;
    let first;
    let second;
    try {
        rejected = new WebSocket(`${runtime.url}?token=wrong`);
        assert.deepEqual(await nextClose(rejected), { code: 1008, reason: 'unauthorized' });

        first = await openSocket(runtime.url);
        first.send('pair-me');
        first.send(JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'initialize', params: {} }));
        assert.equal((await nextMessage(first)).method, 'initialize');
        const firstClosed = nextClose(first);
        second = await openSocket(`${runtime.url}?token=pair-me`);
        assert.equal((await firstClosed).code, 1006);
        second.send(JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'initialize', params: {} }));
        assert.equal((await nextMessage(second)).method, 'initialize');
    } finally {
        await stopBridge(runtime, [rejected, first, second]);
    }
});

test('rejects a binary first-frame token without authenticating or writing stdin', async () => {
    let writes = 0;
    const runtime = await startInjectedRuntime({
        write: () => { writes += 1; return true; },
        options: { token: 'pair-me' },
    });
    let socket;
    try {
        socket = await openSocket(runtime.url);
        const closed = nextClose(socket);
        socket.send(Buffer.from('pair-me'));
        socket.send('pair-me');
        assert.deepEqual(await closed, { code: 1003, reason: 'binary frames unsupported' });
        assert.equal(writes, 0);
    } finally {
        await stopBridge(runtime, [socket]);
    }
});

test('rejects a binary JSON-RPC frame after token authentication without writing stdin', async () => {
    let writes = 0;
    const runtime = await startInjectedRuntime({
        write: () => { writes += 1; return true; },
        options: { token: 'pair-me' },
    });
    let socket;
    try {
        socket = await openSocket(runtime.url + '?token=pair-me');
        const closed = nextClose(socket);
        socket.send(Buffer.from(JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'initialize', params: {} })));
        socket.send(JSON.stringify({ jsonrpc: '2.0', id: 2, method: 'initialize', params: {} }));
        assert.deepEqual(await closed, { code: 1003, reason: 'binary frames unsupported' });
        assert.equal(writes, 0);
    } finally {
        await stopBridge(runtime, [socket]);
    }
});

test('closes an unauthenticated first-frame client after the configured token timeout', async () => {
    const runtime = await startBridge({ token: 'pair-me', authTimeoutMs: 25 });
    let socket;
    try {
        socket = await openSocket(runtime.url);
        assert.deepEqual(await nextClose(socket), { code: 1008, reason: 'authentication timeout' });
    } finally {
        await stopBridge(runtime, [socket]);
    }
});

async function assertAuthTimeoutCleared(event) {
    const timers = [];
    let socket;
    const runtime = await startBridge({
        token: 'pair-me',
        authTimeoutMs: 25,
        timers: {
            setTimeout: (callback, delayMs, ...args) => {
                const timer = { callback, delayMs, args, cleared: false };
                timers.push(timer);
                return timer;
            },
            clearTimeout: (timer) => {
                if (timer && typeof timer === 'object') timer.cleared = true;
            },
        },
    });
    try {
        socket = await openSocket(runtime.url);
        const authTimer = timers.find((timer) => timer.delayMs === 25);
        assert.ok(authTimer, 'authentication timeout was scheduled');
        await event(socket, [...runtime.wss.clients][0]);
        assert.equal(authTimer.cleared, true);
    } finally {
        await stopBridge(runtime, [socket]);
    }
}

test('clears the auth timeout when an unauthenticated client closes first', async () => {
    await assertAuthTimeoutCleared(async (socket, serverSocket) => {
        const disconnected = nextClose(socket);
        serverSocket.terminate();
        await disconnected;
    });
});

test('clears the auth timeout when an unauthenticated client errors first', async () => {
    await assertAuthTimeoutCleared(async (_socket, serverSocket) => {
        assert.doesNotThrow(() => serverSocket.emit('error', new Error('client socket failed')));
    });
});

test('reads the token timeout from the runtime environment', async () => {
    const runtime = await startBridge({ token: 'pair-me', extraEnv: { DSH_AUTH_TIMEOUT_MS: '25' } });
    let socket;
    try {
        socket = await openSocket(runtime.url);
        assert.deepEqual(await nextClose(socket), { code: 1008, reason: 'authentication timeout' });
    } finally {
        await stopBridge(runtime, [socket]);
    }
});

test('disconnect clears the active client and child exit closes the listening port', async () => {
    const runtime = await startBridge();
    let first;
    let second;
    try {
        first = await openSocket(runtime.url);
        await closeSocket(first);
        second = await openSocket(runtime.url);
        second.send(JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'exit', params: {} }));
        await withTimeout(once(runtime.wss, 'close'), 'server closes after dsh exit');
        await assert.rejects(() => openSocket(runtime.url));
    } finally {
        await stopBridge(runtime, [first, second]);
    }
});

test('closes a client when dsh stdin signals bounded backpressure', async () => {
    const runtime = await startInjectedBridge(() => false);
    let socket;
    try {
        socket = await openSocket(runtime.url);
        const closed = nextClose(socket);
        socket.send(JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'backpressure', params: {} }));
        assert.deepEqual(await closed, { code: 1013, reason: 'dsh stdin backpressure' });
    } finally {
        await stopBridge(runtime, [socket]);
    }
});

test('does not write subsequent frames after dsh stdin enters backpressure', async () => {
    let writes = 0;
    const runtime = await startInjectedRuntime({ write: () => { writes += 1; return false; } });
    let socket;
    try {
        socket = await openSocket(runtime.url);
        const closed = nextClose(socket);
        socket.send(JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'first', params: {} }));
        socket.send(JSON.stringify({ jsonrpc: '2.0', id: 2, method: 'second', params: {} }));
        assert.deepEqual(await closed, { code: 1013, reason: 'dsh stdin backpressure' });
        await delay(20);
        assert.equal(writes, 1);
    } finally {
        await stopBridge(runtime, [socket]);
    }
});

test('does not resume writes when dsh stdin drains after backpressure close begins', async () => {
    const stdin = new EventEmitter();
    let writes = 0;
    stdin.write = () => { writes += 1; return false; };
    const child = new EventEmitter();
    child.stdout = new EventEmitter();
    child.stdout.setEncoding = () => {};
    child.stderr = new EventEmitter();
    child.stderr.setEncoding = () => {};
    child.stdin = stdin;
    child.kill = () => { child.killed = true; child.exitCode = 0; child.emit('exit', 0); };
    const runtime = runServer({ spawn: () => child, WebSocketServer }, { port: 0 });
    let socket;
    try {
        await withTimeout(once(runtime.wss, 'listening'), 'drain test listen');
        socket = await openSocket(`ws://127.0.0.1:${runtime.wss.address().port}`);
        const closed = nextClose(socket);
        socket.send(JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'first', params: {} }));
        assert.deepEqual(await closed, { code: 1013, reason: 'dsh stdin backpressure' });
        stdin.emit('drain');
        socket.send(JSON.stringify({ jsonrpc: '2.0', id: 2, method: 'second', params: {} }));
        await delay(20);
        assert.equal(writes, 1);
    } finally {
        await stopBridge(runtime, [socket]);
    }
});

test('shuts down cleanly when dsh stdin emits EPIPE', async () => {
    const stdin = new EventEmitter();
    stdin.write = () => true;
    const runtime = await startInjectedRuntime({ stdin });
    try {
        const serverClosed = withTimeout(once(runtime.wss, 'close'), 'stdin error closes server');
        const epipe = Object.assign(new Error('broken pipe'), { code: 'EPIPE' });
        assert.doesNotThrow(() => stdin.emit('error', epipe));
        await serverClosed;
        assert.equal(runtime.dsh.killed, true);
    } finally {
        await stopBridge(runtime);
    }
});

test('shuts down cleanly when a dsh stdin write throws EPIPE', async () => {
    const runtime = await startInjectedRuntime({
        write: () => { throw Object.assign(new Error('broken pipe'), { code: 'EPIPE' }); },
    });
    let socket;
    try {
        socket = await openSocket(runtime.url);
        const serverClosed = withTimeout(once(runtime.wss, 'close'), 'stdin write error closes server');
        socket.send(JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'write-error', params: {} }));
        await serverClosed;
        assert.equal(runtime.dsh.killed, true);
    } finally {
        await stopBridge(runtime, [socket]);
    }
});

test('rejects a replacement client until dsh stdin emits drain after backpressure', async () => {
    const stdin = new EventEmitter();
    let writes = 0;
    stdin.write = () => { writes += 1; return false; };
    const child = new EventEmitter();
    child.stdout = new EventEmitter();
    child.stdout.setEncoding = () => {};
    child.stderr = new EventEmitter();
    child.stderr.setEncoding = () => {};
    child.stdin = stdin;
    child.kill = () => { child.killed = true; child.exitCode = 0; child.emit('exit', 0); };
    const runtime = runServer({ spawn: () => child, WebSocketServer }, { port: 0 });
    let first;
    let second;
    try {
        await withTimeout(once(runtime.wss, 'listening'), 'reconnect backpressure listen');
        const url = `ws://127.0.0.1:${runtime.wss.address().port}`;
        first = await openSocket(url);
        const firstClosed = nextClose(first);
        first.send(JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'first', params: {} }));
        assert.deepEqual(await firstClosed, { code: 1013, reason: 'dsh stdin backpressure' });

        second = await openSocket(url);
        const secondClosed = nextClose(second);
        second.send(JSON.stringify({ jsonrpc: '2.0', id: 2, method: 'replacement', params: {} }));
        assert.deepEqual(await secondClosed, { code: 1013, reason: 'dsh stdin backpressure' });
        assert.equal(writes, 1);
    } finally {
        await stopBridge(runtime, [first, second]);
    }
});

test('waits for a SIGTERM-ignoring child and escalates to SIGKILL before one exit callback', async () => {
    const child = spawn(process.execPath, ['-e', 'process.on("SIGTERM", () => {}); process.stdout.write("ready"); setInterval(() => {}, 1000);'], {
        stdio: ['pipe', 'pipe', 'pipe'],
    });
    const exits = [];
    const runtime = runServer(
        { spawn: () => child, WebSocketServer, exit: (code) => exits.push(code) },
        { port: 0, childKillTimeoutMs: 25 },
    );
    try {
        await withTimeout(once(runtime.wss, 'listening'), 'SIGKILL escalation listen');
        await withTimeout(once(child.stdout, 'data'), 'SIGTERM-ignoring child ready');
        await runtime.close({ exitCode: 0 });
        assert.equal(child.signalCode, 'SIGKILL');
        assert.deepEqual(exits, [0]);
    } finally {
        if (child.exitCode === null) child.kill('SIGKILL');
    }
});

test('public entry exits nonzero when dsh is absent from PATH', async () => {
    const emptyPath = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-bridge-no-dsh-'));
    const bridge = spawn(process.execPath, ['bridge.js'], {
        cwd: HERE,
        env: { ...process.env, PATH: emptyPath, PORT: '0' },
        stdio: ['ignore', 'ignore', 'pipe'],
    });
    try {
        const [code] = await withTimeout(once(bridge, 'exit'), 'missing dsh public-entry exit');
        assert.equal(code, 1);
    } finally {
        if (bridge.exitCode === null) bridge.kill('SIGKILL');
        fs.rmSync(emptyPath, { recursive: true, force: true });
    }
});

test('constructor failure reuses TERM-to-KILL cleanup for a SIGTERM-ignoring child', async () => {
    const child = spawn(process.execPath, ['-e', 'process.on("SIGTERM", () => {}); process.stdout.write("ready"); setInterval(() => {}, 1000);'], {
        stdio: ['pipe', 'pipe', 'pipe'],
    });
    const exits = [];
    class ThrowingWebSocketServer {
        constructor() { throw new Error('constructor failed'); }
    }
    try {
        await withTimeout(once(child.stdout, 'data'), 'constructor child ready');
        assert.throws(
            () => runServer({ spawn: () => child, WebSocketServer: ThrowingWebSocketServer, exit: (code) => exits.push(code) }, { childKillTimeoutMs: 25 }),
            /constructor failed/,
        );
        await withTimeout(once(child, 'exit'), 'constructor child SIGKILL');
        assert.equal(child.signalCode, 'SIGKILL');
        assert.deepEqual(exits, [1]);
    } finally {
        if (child.exitCode === null) child.kill('SIGKILL');
    }
});

test('concurrent close calls share the same completion promise until a stubborn child exits', async () => {
    const child = spawn(process.execPath, ['-e', 'process.on("SIGTERM", () => {}); process.stdout.write("ready"); setInterval(() => {}, 1000);'], {
        stdio: ['pipe', 'pipe', 'pipe'],
    });
    const exits = [];
    const runtime = runServer(
        { spawn: () => child, WebSocketServer, exit: (code) => exits.push(code) },
        { port: 0, childKillTimeoutMs: 25 },
    );
    try {
        await withTimeout(once(runtime.wss, 'listening'), 'concurrent close listen');
        await withTimeout(once(child.stdout, 'data'), 'concurrent close child ready');
        const first = runtime.close({ exitCode: 0 });
        const second = runtime.close({ exitCode: 0 });
        assert.strictEqual(second, first);
        await first;
        assert.equal(child.signalCode, 'SIGKILL');
        assert.deepEqual(exits, [0]);
    } finally {
        if (child.exitCode === null) child.kill('SIGKILL');
    }
});
