#!/usr/bin/env node
/**
 * dsh-acp-ws-bridge — transport-only stdio<->WebSocket adapter for DSH.
 *
 * It spawns `dsh --profile acp` (NDJSON JSON-RPC over stdio) and mirrors it to a WebSocket:
 *   - DSH stdout line -> JSON.parse -> WebSocket send(text)
 *   - WebSocket text frame -> JSON.stringify + "\n" -> DSH stdin.write
 *
 * It holds NO business state: no session caching, no message buffering, no auth decisions
 * beyond an optional static pairing token. If DSH later speaks native WS ACP, delete this file.
 *
 * Usage:
 *   node bridge.js                 # listens on 127.0.0.1:8765
 *   DSH_TOKEN=secret node bridge.js
 *   PORT=9000 TOKEN=secret node bridge.js
 *
 * Requires: npm install ws
 */
'use strict';

const { spawn } = require('child_process');
const { WebSocket } = require('ws');

/**
 * Pure helpers (exported for tests). The bridge does no business logic beyond these.
 */
function tryParseLine(line) {
    try { return JSON.parse(line); } catch { return undefined; }
}

/** Split a stdout chunk on newlines, retaining each raw line's byte length. */
function splitLines(buffer) {
    const lines = [];
    let idx;
    while ((idx = buffer.indexOf('\n')) >= 0) {
        const raw = buffer.slice(0, idx);
        const line = raw.trim();
        buffer = buffer.slice(idx + 1);
        lines.push({ line, byteLength: Buffer.byteLength(raw) });
    }
    return { lines, rest: buffer };
}

// Only run the live server when executed directly (not when required by tests).
if (require.main === module) {
    const { WebSocketServer } = require('ws');
    runServer({ spawn, WebSocketServer, exit: process.exit });
}

function runServer(deps, options = {}) {
    const { spawn } = deps;
    const WebSocketServer = deps.WebSocketServer;
    const env = options.env || process.env;

    const HOST = options.host === undefined ? '127.0.0.1' : options.host;
    const PORT = options.port === undefined ? Number(env.PORT || 8765) : options.port;
    const TOKEN = options.token === undefined ? (env.DSH_TOKEN || env.TOKEN || '') : options.token;
    const PING_INTERVAL_MS = 30_000;
    const AUTH_TIMEOUT_MS = options.authTimeoutMs === undefined ? Number(env.DSH_AUTH_TIMEOUT_MS || 5_000) : options.authTimeoutMs;
    const MAX_STDOUT_BUFFER_BYTES = options.maxStdoutBufferBytes === undefined ? 1024 * 1024 : options.maxStdoutBufferBytes;
    const CHILD_KILL_TIMEOUT_MS = options.childKillTimeoutMs === undefined ? 1_000 : options.childKillTimeoutMs;
    const signalProcess = options.signalProcess || (deps.exit ? process : null);
    const setTimer = options.setTimeout || setTimeout;
    const clearTimer = options.clearTimeout || clearTimeout;

    if (HOST !== '127.0.0.1') throw new Error('bridge must bind to 127.0.0.1');

    // 1. Spawn DSH over stdio (NDJSON JSON-RPC).
    const dsh = spawn('dsh', ['--profile', 'acp'], { stdio: ['pipe', 'pipe', 'pipe'], env });
    let client = null;
    let closed = false;
    let exited = false;
    let stdinBackpressured = false;
    let exitCode;
    let wss;
    let ping;
    let killTimer;
    let shutdownPromise;
    let resolveChildExit;
    const childExited = new Promise((resolve) => { resolveChildExit = resolve; });

    function close({ exitCode: requestedExitCode } = {}) {
        if (shutdownPromise) return shutdownPromise;
        closed = true;
        exitCode = requestedExitCode;
        clearInterval(ping);
        if (client) { try { client.terminate(); } catch {} }
        if (wss) for (const socket of wss.clients) { try { socket.terminate(); } catch {} }
        if (!exited) {
            try { dsh.kill('SIGTERM'); } catch {}
            killTimer = setTimer(() => {
                if (!exited) {
                    try { dsh.kill('SIGKILL'); } catch {}
                }
            }, CHILD_KILL_TIMEOUT_MS);
        }
        const serverClosed = wss ? new Promise((resolve) => wss.close(resolve)) : Promise.resolve();
        shutdownPromise = Promise.all([childExited, serverClosed]).then(finishExit);
        return shutdownPromise;
    }

    let didExit = false;
    function finishExit() {
        if (!didExit && deps.exit && exitCode !== undefined) {
            didExit = true;
            deps.exit(exitCode);
        }
    }

    function stopForChildFailure(code, message) {
        console.error(message);
        close({ exitCode: code ?? 1 });
    }

    dsh.on('exit', (code) => {
        exited = true;
        clearTimer(killTimer);
        resolveChildExit();
        if (!closed) stopForChildFailure(code, `[bridge] dsh exited code=${code}`);
    });
    dsh.on('error', (err) => {
        exited = true;
        clearTimer(killTimer);
        resolveChildExit();
        stopForChildFailure(1, `[bridge] failed to spawn dsh: ${err.message}`);
    });

    // Buffer partial lines across stdout chunks.
    let buffer = '';
    dsh.stdout.setEncoding('utf8');
    dsh.stdout.on('data', (chunk) => {
        buffer += chunk;
        const { lines, rest } = splitLines(buffer);
        buffer = rest;
        if (Buffer.byteLength(buffer) > MAX_STDOUT_BUFFER_BYTES) {
            console.error('[bridge] dsh stdout buffer limit exceeded');
            close({ exitCode: 1 });
            return;
        }
        for (const { line, byteLength } of lines) {
            if (byteLength > MAX_STDOUT_BUFFER_BYTES) {
                console.error('[bridge] dsh stdout line limit exceeded');
                close({ exitCode: 1 });
                return;
            }
            if (tryParseLine(line) === undefined) continue;
            broadcast(line);
        }
    });
    if (dsh.stderr) {
        dsh.stderr.setEncoding('utf8');
        dsh.stderr.on('data', (chunk) => console.error(`[bridge:dsh] ${chunk.trimEnd()}`));
    }
    if (dsh.stdin.on) {
        dsh.stdin.on('drain', () => { stdinBackpressured = false; });
        dsh.stdin.on('error', (err) => stopForChildFailure(1, `[bridge] dsh stdin failed: ${err.message}`));
    }

    // 2. WebSocket server.
    try {
        wss = new WebSocketServer({ host: HOST, port: PORT });
    } catch (err) {
        close({ exitCode: 1 });
        throw err;
    }
    wss.on('error', (err) => stopForChildFailure(1, `[bridge] websocket server failed: ${err.message}`));
    wss.on('connection', (ws, req) => {
        // Optional static token auth: ?token=... or first text frame "TOKEN:..."
        const url = new URL(req.url, `http://${HOST}`);
        const qToken = url.searchParams.get('token') || '';
        let authTimeout;
        ws.once('close', () => clearTimer(authTimeout));
        ws.once('error', () => clearTimer(authTimeout));

        const finish = () => {
            clearTimer(authTimeout);
            // Single client: drop any previous connection (tech spec §10).
            if (client && client !== ws) { try { client.terminate(); } catch {} }
            client = ws;
            console.error(`[bridge] client connected (${req.socket.remoteAddress})`);

            ws.on('message', (data, isBinary) => {
                if (closed || ws !== client) return;
                if (isBinary) {
                    client = null;
                    ws.removeAllListeners('message');
                    ws.close(1003, 'binary frames unsupported');
                    return;
                }
                if (stdinBackpressured) {
                    client = null;
                    ws.removeAllListeners('message');
                    ws.close(1013, 'dsh stdin backpressure');
                    return;
                }
                const text = data.toString();
                if (!text) return;
                if (tryParseLine(text) === undefined) return;
                let writable;
                try {
                    writable = dsh.stdin.write(text + '\n');
                } catch (err) {
                    stopForChildFailure(1, `[bridge] dsh stdin failed: ${err.message}`);
                    return;
                }
                if (!writable) {
                    stdinBackpressured = true;
                    client = null;
                    ws.removeAllListeners('message');
                    ws.close(1013, 'dsh stdin backpressure');
                }
            });

            ws.on('close', () => { clearTimer(authTimeout); if (client === ws) client = null; console.error('[bridge] client disconnected'); });
            ws.on('error', () => { if (client === ws) client = null; });
        };

        if (TOKEN) {
            if (qToken) {
                if (qToken === TOKEN) finish();
                else ws.close(1008, 'unauthorized');
                return;
            }
            const onFirst = (data, isBinary) => {
                clearTimer(authTimeout);
                if (isBinary) {
                    ws.removeAllListeners('message');
                    ws.close(1003, 'binary frames unsupported');
                    return;
                }
                const t = data.toString().trim();
                ws.removeListener('message', onFirst);
                if (t === TOKEN) { finish(); }
                else { ws.close(1008, 'unauthorized'); }
            };
            ws.once('message', onFirst);
            authTimeout = setTimer(() => ws.close(1008, 'authentication timeout'), AUTH_TIMEOUT_MS);
        } else {
            finish();
        }
    });

    // 3. Heartbeat: ping every 30s.
    ping = setInterval(() => {
        if (client && client.readyState === WebSocket.OPEN) client.ping();
    }, PING_INTERVAL_MS);

    wss.on('close', () => clearInterval(ping));
    if (signalProcess) {
        for (const signal of ['SIGINT', 'SIGTERM', 'SIGHUP']) {
            signalProcess.once(signal, () => close({ exitCode: 0 }));
        }
    }

    function broadcast(text) {
        if (!client || client.readyState !== WebSocket.OPEN) return;
        if (client.bufferedAmount > 1024 * 1024) {
            client.close(1013, 'websocket backpressure');
            return;
        }
        client.send(text);
    }

    console.error(`[bridge] listening on ws://${HOST}:${PORT}${TOKEN ? ' (token required)' : ''}`);
    return { wss, dsh, close };
}

module.exports = { splitLines, tryParseLine, runServer };
