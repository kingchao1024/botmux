# Handoff provenance

The bridge was imported from the verified handoff package before local changes.
The initial import intentionally excluded `node_modules/` and macOS `._*`
metadata. The following SHA-256 values are the source-of-record values from
the handoff manifest.

| Original file | SHA-256 |
| --- | --- |
| `README.md` | `dc9b899631636fc762fab310a85ce1f7a830048a8a219b583f1190463da84588` |
| `bridge.js` | `e125eb95f72bbc8cd4f108e2de8422fc16191cd6c9f9b17d94f026ec310249fe` |
| `bridge.test.js` | `19eeb2e25f24e0007bbe391507aad5c14fcc30be2146753a1b6a8d5eebc873a2` |
| `install-and-start.sh` | `907b779aeb6846dfe586781937a3b114b44592e43773fa6415b1197f77c5f3ce` |
| `package-lock.json` | `8a735686f5e6fd4659f1b3a93d9d66e714533aed6b3cd727735b744b613116bc` |
| `package.json` | `94d9293f3fbb94a234e9811b75c381d18941d63c416f9e07965f4a723121b261` |

The enclosing handoff also supplied these integrity anchors:

| Handoff artifact | SHA-256 |
| --- | --- |
| `handoff/SHA256SUMS` manifest | `2f8b1aa7bfe4e2f31195eb519e294d00b5b3a9c15cfafbc0a5eab32a57e262a6` |
| `bridge/dsh-acp-ws-bridge-0.1.0.tar.gz` | `7f8e03cfc7810ee052ee8d86f3bda5a6334353c7d12c0068e65f0e29efdb6e97` |

The imported sources have since received repository-local contract fixes and
tests; this file records provenance, not the current file hashes.
