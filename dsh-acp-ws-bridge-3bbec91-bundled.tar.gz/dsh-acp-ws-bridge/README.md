# dsh-acp-ws-bridge

A tiny (<200 line) **transport-only** bridge that runs inside **Android proot Ubuntu** and lets the
DSH Android app talk to `dsh --profile acp` over a loopback WebSocket.

DSH speaks ACP v1 as **NDJSON JSON-RPC over stdio**. The Android app speaks JSON-RPC over a
WebSocket. This process converts between the two. It holds **no business state**: no session
cache, no message buffering, no auth decision beyond a static token. If DSH ever exposes a native
WS ACP endpoint, this bridge can be deleted.

## What it does

```
dsh --profile acp (stdio NDJSON)  <==>  this bridge  <==>  ws://127.0.0.1:8765
```

- stdout of DSH is split on `\n`, parsed as JSON, and sent to the connected WS client.
- Incoming WS text frames are parsed as JSON, appended with `\n`, and written to DSH stdin.
- Only **one** client at a time — a new connection drops the previous one.
- WS ping/pong every 30s.
- An unterminated DSH stdout line is capped at 1 MiB; overflow shuts down the
  bridge and terminates DSH rather than retaining unbounded input. Completed
  NDJSON lines have the same 1 MiB cap.

## Requirements

- Node.js 18+ (already present in the proot Ubuntu image used by DSH).
- The `ws` package.

## Install & run

```bash
cd dsh-acp-ws-bridge
npm ci                 # installs the locked ws version
node bridge.js
```

You should see:

```
[bridge] dsh-acp-ws-bridge listening on ws://127.0.0.1:8765
```

Then in the app: 设置 → DSH WebSocket 地址 = `ws://127.0.0.1:8765`.

## Configuration (env vars)

| Var        | Default           | Meaning                                   |
|------------|-------------------|-------------------------------------------|
| `PORT`     | `8765`            | WS port.                                  |
| `DSH_TOKEN`| (empty)           | Optional pairing token. Empty = no auth.  |
| `DSH_AUTH_TIMEOUT_MS` | `5000` | Time allowed for first-frame token authentication. |

If `DSH_TOKEN` is set, the client must either:
- connect to `ws://127.0.0.1:8765?token=YOUR_TOKEN`, or
- send the token as the **first** WS text frame.

Any other client gets a `1008 unauthorized` close.
When no query token is supplied, an unauthenticated client is closed with
`1008 authentication timeout` after `DSH_AUTH_TIMEOUT_MS`.

## Security notes

- The bridge binds **only** to `127.0.0.1`. The Android app's `network_security_config` likewise
  permits cleartext **only** for loopback.
- The bridge does not persist or log messages; it only forwards bytes.
- A DSH stdin error, including EPIPE, shuts the bridge down instead of
  surfacing as an uncaught stream or write error.
- If DSH stdin signals backpressure, the current client is closed with `1013`;
  all clients are rejected until DSH emits `drain`, so reconnecting cannot
  resume writes prematurely.
- `SIGINT`, `SIGTERM`, `SIGHUP`, child exits, and WebSocket startup failures use
  one idempotent shutdown path that closes sockets, waits for DSH to exit, and
  escalates a child that ignores `SIGTERM` to `SIGKILL` after one second.
  Concurrent shutdown callers share that same completion promise.
- Permission requests (`session/request_permission`) are forwarded untouched to the app, which
  is fail-closed (120s auto-deny, no "always allow").

## Test

```bash
npm test
```

The suite uses a PATH-injected fake `dsh` process to prove the actual spawn
arguments are `dsh --profile acp`. It verifies the full NDJSON relay contract
(`initialize`, `session/new`, `session/prompt`/`session/update`, permission,
and cancel), plus partial and invalid lines, token rejection, one-client
replacement, disconnect/child-exit cleanup, stderr, and bounded backpressure.
It is an automated transport-contract check only: running it does not prove a
real DSH binary inside proot or an Android device integration.

## Handoff provenance

The original handoff file hashes and enclosing handoff anchors are recorded in
[`HANDOFF_PROVENANCE.md`](HANDOFF_PROVENANCE.md).
