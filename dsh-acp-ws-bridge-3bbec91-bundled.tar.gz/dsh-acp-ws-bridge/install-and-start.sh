#!/usr/bin/env bash
set -euo pipefail

VERSION="0.1.0"
BASE_DIR="${HOME}/.local/share/dsh-acp-ws-bridge"
RELEASE_DIR="${BASE_DIR}/releases/${VERSION}"
CURRENT_LINK="${BASE_DIR}/current"
STATE_DIR="${HOME}/.local/state/dsh-acp-ws-bridge"
PID_FILE="${STATE_DIR}/bridge.pid"
TOKEN_FILE="${STATE_DIR}/token"
LOG_FILE="${STATE_DIR}/bridge.log"
SOURCE_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"

command -v node >/dev/null 2>&1 || { printf '%s\n' '错误：未找到 Node.js，请先在 proot Ubuntu 中安装 Node.js 18+。' >&2; exit 1; }
command -v dsh >/dev/null 2>&1 || { printf '%s\n' '错误：未找到 dsh 命令。请先确认在当前 proot Ubuntu 中可以执行 dsh。' >&2; exit 1; }

mkdir -p "${BASE_DIR}/releases" "${STATE_DIR}"
rm -rf "${RELEASE_DIR}.tmp"
mkdir -p "${RELEASE_DIR}.tmp"
cp "${SOURCE_DIR}/bridge.js" "${SOURCE_DIR}/package.json" "${SOURCE_DIR}/package-lock.json" "${SOURCE_DIR}/README.md" "${SOURCE_DIR}/bridge.test.js" "${RELEASE_DIR}.tmp/"
if [ -d "${SOURCE_DIR}/node_modules/ws" ]; then
  mkdir -p "${RELEASE_DIR}.tmp/node_modules"
  cp -R "${SOURCE_DIR}/node_modules/ws" "${RELEASE_DIR}.tmp/node_modules/"
else
  (cd "${RELEASE_DIR}.tmp" && npm ci --omit=dev --no-audit --no-fund)
fi
rm -rf "${RELEASE_DIR}"
mv "${RELEASE_DIR}.tmp" "${RELEASE_DIR}"
ln -sfn "${RELEASE_DIR}" "${CURRENT_LINK}"

if [ -f "${PID_FILE}" ]; then
  OLD_PID="$(tr -cd '0-9' < "${PID_FILE}")"
  if [ -n "${OLD_PID}" ] && kill -0 "${OLD_PID}" 2>/dev/null; then
    kill "${OLD_PID}" 2>/dev/null || true
    for _ in 1 2 3 4 5; do
      kill -0 "${OLD_PID}" 2>/dev/null || break
      sleep 1
    done
  fi
  rm -f "${PID_FILE}"
fi

if [ ! -s "${TOKEN_FILE}" ]; then
  umask 077
  od -An -N24 -tx1 /dev/urandom | tr -d ' \n' > "${TOKEN_FILE}"
fi
TOKEN="$(tr -d '\r\n' < "${TOKEN_FILE}")"

nohup env HOST=127.0.0.1 PORT=8765 DSH_TOKEN="${TOKEN}" node "${CURRENT_LINK}/bridge.js" >>"${LOG_FILE}" 2>&1 &
PID=$!
printf '%s\n' "${PID}" > "${PID_FILE}"
sleep 2

if ! kill -0 "${PID}" 2>/dev/null; then
  printf '%s\n' '启动失败，最近日志：' >&2
  tail -n 30 "${LOG_FILE}" >&2 || true
  exit 1
fi

printf '%s\n' 'DSH Bridge 已安装并启动。'
printf 'WebSocket 地址：%s\n' 'ws://127.0.0.1:8765'
printf '配对 Token：%s\n' "${TOKEN}"
printf '日志：%s\n' "${LOG_FILE}"
printf '停止命令：kill %s\n' "${PID}"
