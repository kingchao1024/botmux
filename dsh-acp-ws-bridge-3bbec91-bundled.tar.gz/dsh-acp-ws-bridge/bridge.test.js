'use strict';

const assert = require('node:assert/strict');
const { EventEmitter, once } = require('node:events');
const test = require('node:test');
const { WebSocketServer, WebSocket } = require('ws');
const { splitLines, tryParseLine, runServer } = require('./bridge.js');

const TIMEOUT_MS = 2_000;

function wait(promise, label) {
    return Promise.race([
        promise,
        new Promise((_, reject) => setTimeout(() => reject(new Error(`timed out: ${label}`)), TIMEOUT_MS)),
    ]);
}

test('splitLines keeps partial NDJSON tails', { timeout: TIMEOUT_MS }, () => {
    const result = splitLines('{\"a\":1}\n{\"b\":2}\n{\"c\":');
    assert.deepEqual(result.lines, [
        { line: '{\"a\":1}', byteLength: 7 },
        { line: '{\"b\":2}', byteLength: 7 },
    ]);
    assert.equal(result.rest, '{\"c\":');
});

test('splitLines keeps whitespace-only complete lines for byte-limit checks', { timeout: TIMEOUT_MS }, () => {
    assert.deepEqual(splitLines('        \n').lines, [{ line: '', byteLength: 8 }]);
});

test('tryParseLine accepts JSON and rejects garbage', { timeout: TIMEOUT_MS }, () => {
    assert.deepEqual(tryParseLine('{\"x\":1}'), { x: 1 });
    assert.equal(tryParseLine('not json'), undefined);
});

test('forwards loopback WebSocket frames and replaces an old client', { timeout: TIMEOUT_MS }, async () => {
    const stdin = { writes: [], write(line) { this.writes.push(line); return true; } };
    const stdout = new EventEmitter();
    stdout.setEncoding = () => {};
    const stderr = new EventEmitter();
    stderr.setEncoding = () => {};
    const child = new EventEmitter();
    child.stdout = stdout;
    child.stderr = stderr;
    child.stdin = stdin;
    child.kill = () => { child.killed = true; child.exitCode = 0; child.emit('exit', 0); };
    const runtime = runServer({ spawn: () => child, WebSocketServer }, { port: 0 });
    let first;
    let second;
    try {
        await wait(once(runtime.wss, 'listening'), 'bridge listen');
        const url = `ws://127.0.0.1:${runtime.wss.address().port}`;
        first = new WebSocket(url);
        await wait(once(first, 'open'), 'first client open');
        const received = once(first, 'message');
        stdout.emit('data', '{\"jsonrpc\":\"2.0\",\"id\":1,\"result\":{}}\n');
        assert.equal((await wait(received, 'DSH output')).at(0).toString(), '{\"jsonrpc\":\"2.0\",\"id\":1,\"result\":{}}');

        first.send('{\"jsonrpc\":\"2.0\",\"method\":\"ping\"}');
        await wait(new Promise((resolve) => setTimeout(resolve, 20)), 'stdin forwarding');
        assert.deepEqual(stdin.writes, ['{\"jsonrpc\":\"2.0\",\"method\":\"ping\"}\n']);

        const closed = once(first, 'close');
        second = new WebSocket(url);
        await wait(once(second, 'open'), 'second client open');
        assert.equal((await wait(closed, 'first client replacement')).at(0), 1006);
    } finally {
        for (const socket of [first, second]) {
            if (socket && socket.readyState !== WebSocket.CLOSED) socket.terminate();
        }
        await runtime.close();
    }
});
